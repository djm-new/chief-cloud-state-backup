# Standalone spend briefing fallback

## When to use

Use this pattern when a cron-delivered spend briefing script is meant to run outside the Hermes app/runtime and cannot rely on `agent.*` or `hermes_constants` being importable.

## What the fix looked like

- Add a tiny shared helper, e.g. `spend_report_helper.py`.
- In the helper, try the rich Hermes path first:
  - `from hermes_state import SessionDB`
  - `from agent.insights import InsightsEngine`
- If that import path fails, fall back to direct SQLite reads from `/opt/data/spend.db`.
- Resolve `HERMES_HOME` locally with `os.getenv("HERMES_HOME")` or `Path.home() / ".hermes"` instead of importing `hermes_constants`.

## Why this mattered

A cron script that imported `agent.spend_ledger` directly crashed before rendering because the cron Python environment did not have Hermes modules on `sys.path`. The fallback helper kept the briefing alive while preserving the richer session-insights path when available.

## Verification

- Run the script with the forced-report flag.
- Confirm it emits a full briefing instead of a traceback.
- Compile the helper and both briefing scripts with `py_compile`.
