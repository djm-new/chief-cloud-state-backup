---
name: github-auth
description: "GitHub auth setup: HTTPS tokens, SSH keys, gh CLI login."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Authentication, Git, gh-cli, SSH, Setup]
    related_skills: [github-pr-workflow, github-code-review, github-issues, github-repo-management]
---

# GitHub Authentication Setup

This skill sets up authentication so the agent can work with GitHub repositories, PRs, issues, and CI. It covers two paths:

- **`git` (always available)** — uses HTTPS personal access tokens or SSH keys
- **`gh` CLI (if installed)** — richer GitHub API access with a simpler auth flow

## Detection Flow

When a user asks you to work with GitHub, run this check first:

```bash
# Check what's available
git --version
gh --version 2>/dev/null || echo "gh not installed"

# Check if already authenticated
gh auth status 2>/dev/null || echo "gh not authenticated"
git config --global credential.helper 2>/dev/null || echo "no git credential helper"
```

**Decision tree:**
1. If `gh auth status` shows authenticated → you're good, use `gh` for everything
2. If `gh` is installed but not authenticated → use "gh auth" method below
3. If `gh` is not installed → use "git-only" method below (no sudo needed)
4. If an expected token fails, **do credential discovery before asking the user**. In DJ's Hermes/Railway environment, stale `GITHUB_TOKEN` values can coexist with valid OAuth/PAT tokens in durable state. Search likely stores and validate candidates with the GitHub `/user` API without printing secrets:

```bash
python3 - <<'PY'
from pathlib import Path
import re, urllib.request, json
patterns = [r'ghp_[A-Za-z0-9_]{36}', r'github_pat_[A-Za-z0-9_]+', r'gho_[A-Za-z0-9_]{36}', r'ghs_[A-Za-z0-9_]{36}']
seen = []
for root in [Path('/opt/data'), Path.home()]:
    if not root.exists():
        continue
    for p in root.rglob('*'):
        if not p.is_file():
            continue
        try:
            if p.stat().st_size > 5_000_000:
                continue
            text = p.read_text(errors='ignore')
        except Exception:
            continue
        for pat in patterns:
            for m in re.finditer(pat, text):
                tok = m.group(0)
                if tok not in seen:
                    seen.append(tok)
for i, tok in enumerate(seen, 1):
    req = urllib.request.Request('https://api.github.com/user', headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json', 'User-Agent': 'hermes'})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.load(r)
        print('VALID_CANDIDATE', i, data.get('login'), tok[:8], tok[-4:])
    except Exception:
        pass
PY
```

Use the valid candidate through `GIT_ASKPASS` or `gh auth login --with-token`; do not paste tokens into output or leave them embedded in remotes.

---

## Method 1: Git-Only Authentication (No gh, No sudo)

This works on any machine with `git` installed. No root access needed.

### Option A: HTTPS with Personal Access Token (Recommended)

This is the most portable method — works everywhere, no SSH config needed.

**Step 1: Create a personal access token**

Tell the user to go to: **https://github.com/settings/tokens**

- Click "Generate new token (classic)"
- Give it a name like "hermes-agent"
- Select scopes:
  - `repo` (full repository access — read, write, push, PRs)
  - `workflow` (trigger and manage GitHub Actions)
  - `read:org` (if working with organization repos)
- Set expiration (90 days is a good default)
- Copy the token — it won't be shown again

**Step 2: Configure git to store the token**

```bash
# Set up the credential helper to cache credentials
# "store" saves to ~/.git-credentials in plaintext (simple, persistent)
git config --global credential.helper store

# Now do a test operation that triggers auth — git will prompt for credentials
# Username: <their-github-username>
# Password: <paste the personal access token, NOT their GitHub password>
git ls-remote https://github.com/<their-username>/<any-repo>.git
```

After entering credentials once, they're saved and reused for all future operations.

**Alternative: cache helper (credentials expire from memory)**

```bash
# Cache in memory for 8 hours (28800 seconds) instead of saving to disk
git config --global credential.helper 'cache --timeout=28800'
```

**Alternative: set the token directly in the remote URL (per-repo)**

```bash
# Embed token in the remote URL (avoids credential prompts entirely)
git remote set-url origin https://<username>:<token>@github.com/<owner>/<repo>.git
```

**Step 3: Configure git identity**

```bash
# Required for commits — set name and email
git config --global user.name "Their Name"
git config --global user.email "their-email@example.com"
```

**Step 4: Verify**

```bash
# Test push access (this should work without any prompts now)
git ls-remote https://github.com/<their-username>/<any-repo>.git

# Verify identity
git config --global user.name
git config --global user.email
```

### Option B: SSH Key Authentication

Good for users who prefer SSH or already have keys set up.

**Step 1: Check for existing SSH keys**

```bash
ls -la ~/.ssh/id_*.pub 2>/dev/null || echo "No SSH keys found"
```

**Step 2: Generate a key if needed**

```bash
# Generate an ed25519 key (modern, secure, fast)
ssh-keygen -t ed25519 -C "their-email@example.com" -f ~/.ssh/id_ed25519 -N ""

# Display the public key for them to add to GitHub
cat ~/.ssh/id_ed25519.pub
```

Tell the user to add the public key at: **https://github.com/settings/keys**
- Click "New SSH key"
- Paste the public key content
- Give it a title like "hermes-agent-<machine-name>"

**Step 3: Test the connection**

```bash
ssh -T git@github.com
# Expected: "Hi <username>! You've successfully authenticated..."
```

**Step 4: Configure git to use SSH for GitHub**

```bash
# Rewrite HTTPS GitHub URLs to SSH automatically
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

**Step 5: Configure git identity**

```bash
git config --global user.name "Their Name"
git config --global user.email "their-email@example.com"
```

---

## Method 2: gh CLI Authentication

If `gh` is installed, it handles both API access and git credentials in one step.

### Interactive Browser Login (Desktop)

```bash
gh auth login
# Select: GitHub.com
# Select: HTTPS
# Authenticate via browser
```

### Token-Based Login (Headless / SSH Servers)

### Token-Based Login (Headless / SSH Servers)

```bash
echo "<THEIR_TOKEN>" | gh auth login --with-token

# Set up git credentials through gh
gh auth setup-git
```

**Headless/PTY fallback rule:** In Telegram, CI, SSH, or other bridged terminals, interactive `gh auth login --web` can stall on prompts such as protocol selection or "Authenticate Git with your GitHub credentials?". Do not keep restarting device-login loops. Try the web/device flow once; if prompt input is unreliable or the device code expires, kill stale `gh auth login` waiters, verify `gh auth status`, and switch to token auth (`GH_TOKEN`/`GITHUB_TOKEN` piped to `gh auth login --with-token`). Keep the user-facing ask concrete: request a PAT with `repo`, `workflow`, and `read:org`; never print tokens back.

Cleanup pattern after a failed interactive auth attempt:

```bash
pkill -f 'gh auth login' || true
gh auth status 2>&1 || true
ps -ef | grep -E 'gh auth|railway login' | grep -v grep || true
```

### Verify

```bash
gh auth status
```

```bash
# Start once, capture the code/URL in the foreground, and relay it clearly.
gh auth login --hostname github.com --git-protocol https --web
# User opens https://github.com/login/device and enters the printed one-time code.

# After approval, verify before doing repo work.
gh auth status
gh auth setup-git
```

Pitfalls:
- PTY prompts such as “Authenticate Git with your GitHub credentials? (Y/n)” can appear stuck in automation. If so, kill the process and prefer `--with-token`.
- Backgrounding `gh auth login --web` can lose the printed device code from logs; capture and relay the code before waiting.
- If a timed foreground login exits while waiting, the device code may still be valid briefly, but a restarted login creates a new code. Tell the user which code is current.
- Do not proceed to `gh repo create`, `git push`, or deployment until `gh auth status` confirms authentication.

### Verify

```bash
gh auth status
```

---

## Using the GitHub API Without gh

When `gh` is not available, you can still access the full GitHub API using `curl` with a personal access token. This is how the other GitHub skills implement their fallbacks.

### Setting the Token for API Calls

```bash
# Option 1: Export as env var (preferred — keeps it out of commands)
export GITHUB_TOKEN="<token>"

# Then use in curl calls:
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user
```

### Extracting the Token from Git Credentials

If git credentials are already configured (via credential.helper store), the token can be extracted:

```bash
# Read from git credential store
grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|'
```

### Helper: Detect Auth Method

Use this pattern at the start of any GitHub workflow:

```bash
# Try gh first, fall back to git + curl
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  echo "AUTH_METHOD=gh"
elif [ -n "$GITHUB_TOKEN" ]; then
  echo "AUTH_METHOD=curl"
elif [ -f ~/.hermes/.env ] && grep -q "^GITHUB_TOKEN=" ~/.hermes/.env; then
  export GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" ~/.hermes/.env | head -1 | cut -d= -f2 | tr -d '\n\r')
  echo "AUTH_METHOD=curl"
elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
  export GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
  echo "AUTH_METHOD=curl"
else
  echo "AUTH_METHOD=none"
  echo "Need to set up authentication first"
fi
```

---

## Railway / Headless Server: No gh, No git-credentials

On Railway (and similar server environments), the most common state is:
- `gh` not installed
- No `~/.git-credentials` file
- No credential helper set
- GitHub token not in `.env`

**Diagnosis:**
```bash
ls ~/.git-credentials 2>/dev/null && echo "exists" || echo "no git-credentials file"
git config --global credential.helper 2>/dev/null || echo "no credential helper set"
command -v gh &>/dev/null && gh auth status || echo "gh not available"
```

**Fastest fix for a one-time push:** embed the PAT directly in the remote URL:
```bash
git remote set-url origin https://<username>:<token>@github.com/<owner>/<repo>.git
git push origin main
# Optionally restore the clean URL after pushing:
git remote set-url origin https://github.com/<owner>/<repo>.git
```

See `references/headless-token-push.md` for the reusable temporary-remote pattern.

**For persistent access:** use `git config --global credential.helper store` and trigger a credential prompt once (via `git ls-remote`), which saves to `~/.git-credentials`.

**When a cron or backup script builds an authenticated Git URL**, keep the token in an env var and expand it at runtime (for example `https://x-access-token:${GITHUB_TOKEN}@github.com/...`). Do not leave a redacted placeholder in the executable script.

**Note:** `openai-codex` provider on Railway is Cloudflare-blocked — this is a separate issue from GitHub auth and unrelated to git push operations.

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `git push` asks for password | GitHub disabled password auth. Use a personal access token as the password, or switch to SSH |
| `remote: Permission to X denied` | Token may lack `repo` scope — regenerate with correct scopes |
| `fatal: Authentication failed` | Cached credentials may be stale — run `git credential reject` then re-authenticate |
| `ssh: connect to host github.com port 22: Connection refused` | Try SSH over HTTPS port: add `Host github.com` with `Port 443` and `Hostname ssh.github.com` to `~/.ssh/config` |
| Credentials not persisting | Check `git config --global credential.helper` — must be `store` or `cache` |
| Multiple GitHub accounts | Use SSH with different keys per host alias in `~/.ssh/config`, or per-repo credential URLs |
| `gh: command not found` + no sudo | Use git-only Method 1 above — no installation needed |
