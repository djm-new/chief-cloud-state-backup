---
name: healthos-app-updates
description: "Use when changing HealthOS app behavior outside workout seed/program imports: meals, daily ledger, dashboard, health metrics, app routes, or UX flows. Emphasizes current-code confirmation before implementation."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [health, healthos, product, meals, daily-ledger, dashboard, ux, nextjs]
    related_skills: [healthos-workout-programs, systematic-debugging]
---

# HealthOS App Updates

## Overview

Use this skill when DJ asks for a HealthOS product or code change outside workout program seed data: meal logging, quick re-log trays, daily ledger/history, dashboard cards, body metrics, calories/TDEE, Apple Watch inputs, routing, or UX behavior.

HealthOS work should be **current-state-first**. Do not merely paraphrase DJ's report as if it were confirmed. Inspect the relevant code paths, confirm whether his understanding matches the implementation, then evaluate the change before writing code.

## When to Use

- Meal logging, meal editing, macro estimates, quick re-log/favorite/frequent meals
- Daily ledger/history changes
- Today dashboard behavior or target/adherence displays
- Weight, calories, sleep, steps, Apple Watch/TDEE logic
- UI/UX flow changes in the HealthOS app
- API route changes for app behavior

For workout seed/program imports, also load `healthos-workout-programs`.

## Required workflow

1. **Confirm the user's understanding from code before implementing.**
   - If DJ says “currently X,” inspect the relevant source files and state whether X is code-confirmed, contradicted, or ambiguous.
   - Avoid saying “understood” in a way that implies verified behavior unless code has been read.
   - If DJ explicitly asks for evaluation before writing, do not edit files until after you have reported the code-confirmed current behavior and proposed approach.

2. **Find the data path, not just the visible component.**
   - Identify the page/server component that loads data.
   - Identify any helper library that shapes the data.
   - Identify the client component that renders or mutates it.
   - Identify the API route(s) called by the client.
   - Identify the Prisma model fields that constrain the implementation.

3. **Evaluate the minimal behavior change.**
   - Prefer changing the data-source/helper layer when the UI already renders a generic list of choices.
   - Preserve existing payload shapes unless the feature truly needs new fields.
   - Keep deleted/soft-deleted data excluded when existing behavior excludes it.
   - Preserve existing date semantics (`app-time` helpers) for meal/day logging.

4. **Clarify product semantics before coding when they affect data meaning.**
   Ask or state a recommendation for choices like:
   - Whether “meal” means exact description only or normalized description.
   - Whether quick re-log should use latest corrected macros, averaged macros, or original macros.
   - Whether ranking is all-time, rolling window, or category-specific.
   - Tie-breakers such as most recent logged time.

5. **Implement with tests when logic changes.**
   - Extract pure ranking/formatting helpers if needed so unit tests do not require a database.
   - Add tests for normalization, deleted-data exclusion where practical, limits, and tie-breakers.
   - Run typecheck and relevant tests before reporting completion.

6. **Distinguish local implementation from live completion.**
   - If DJ is reporting behavior from the production HealthOS app, do not say the change is “implemented” in the user-facing sense until it is committed, pushed/deployed, and the live UI is verified.
   - Use a visible marker from the change (label text, unique copy, or route output) to prove the live app is serving the new build.
   - If only local code changed, say “local commit/code is ready” rather than implying production is updated.
   - Do not stop at the first stale credential or unauthenticated CLI result. For HealthOS, GitHub is the source of truth and Railway is the runtime; search existing durable credential stores/state backups, validate candidates without printing secrets, push the commit, and then verify production before asking DJ for access.

7. **Treat screenshots as live-state evidence.**
   If DJ sends a screenshot after a UI change, inspect the visible labels/copy against the intended marker. A screenshot still showing old copy means the live app has not updated (or the user is on a stale build), regardless of local code state.

## HealthOS meal quick-log/re-log map

As of the meal quick re-log implementation inspected in this session:

- Today page: `app/(app)/page.tsx`
  - Loads quick tray data and passes it to `DailyMealsLedger`.
- Data helper: `lib/recent-meals.ts`
  - Previously implemented most-recent distinct meals using `orderBy: { loggedAt: 'desc' }`, `take: 80`, and normalized descriptions for de-duping.
- UI component: `components/meals/DailyMealsLedger.tsx`
  - Renders the “Quick re-log” chip row.
  - Calls `/api/meals/relog` with description/macros and selected `dateKey`.
- API route: `app/api/meals/relog/route.ts`
  - Creates a new `Meal` without re-running LLM estimation.
- Prisma model: `prisma/schema.prisma` model `Meal`
  - Key fields: `userId`, `date`, `mealCategory`, `loggedAt`, `description`, `calories`, `proteinG`, `carbsG`, `fatG`, `deletedAt`.

### Frequent-meal tray pattern

For a “top N most frequently logged meals” tray:

1. Query non-deleted meals for the current user.
2. Normalize descriptions with `description.trim().toLowerCase()` for grouping, matching the previous distinct behavior.
3. Count occurrences per normalized description.
4. Keep the latest logged meal within each group as the re-log payload, so edited/corrected later entries win.
5. Sort by count descending, then latest `loggedAt` descending as a tie-breaker.
6. Return the requested limit, e.g. DJ requested top 5 rather than the previous 6.

Prefer TypeScript aggregation when normalized grouping matters; Prisma `groupBy` on raw `description` would split case/whitespace variants.

## Common pitfalls

1. **Parroting user-reported behavior as verified.**
   If DJ asks “Have you confirmed this?” the correct answer must distinguish code-confirmed facts from restatement. Always inspect before claiming current behavior.

2. **Writing before evaluation when asked not to.**
   For UX/product behavior changes, DJ may explicitly want confirmation and design evaluation first. Respect that sequence.

3. **Only reading the component.**
   Many HealthOS behaviors are split across server page data loading, `lib/` helpers, client components, API routes, and Prisma models. Trace the full path.

4. **Breaking quick re-log by changing payload shape.**
   Existing quick re-log expects description and macro fields. If the tray is only changing ranking, preserve the payload and API route.

5. **Forgetting soft delete semantics.**
   Meal lists and quick logging should exclude `deletedAt != null` unless the requested feature explicitly needs deleted history.

6. **Changing labels without behavior.**
   If a tray switches from recent to frequent, update names/comments/labels as needed so future maintainers do not misunderstand the source.

## Verification checklist

- [ ] Current behavior confirmed from source paths, not just user report
- [ ] Data path traced: page → helper → component → API → Prisma model
- [ ] Product semantics/tie-breakers documented or clarified
- [ ] Minimal code change identified before editing
- [ ] Tests added/updated for changed ranking or data-shaping logic
- [ ] `npm run typecheck` passes when Node/npm is available
- [ ] Relevant `npm test`/Vitest tests pass when Node/npm is available
- [ ] Local implementation status is clearly distinguished from production/live status
- [ ] If DJ provided a screenshot or is using the live app, actual rendered UI was checked for the new marker
- [ ] If production access is blocked, report the exact remaining deployment gate without claiming the feature is live
