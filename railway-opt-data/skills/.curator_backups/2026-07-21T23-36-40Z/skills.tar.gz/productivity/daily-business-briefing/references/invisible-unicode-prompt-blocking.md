# Invisible Unicode prompt blocking

Session lesson:
- The briefing cron failed because copied Slack text contained invisible Unicode (`U+200B` zero-width space).
- The scanner rejected the prompt before synthesis.

Fix pattern:
1. Normalize *all* upstream briefing inputs before prompt assembly.
2. Strip invisible characters from collector output, filter output, and any fallback reads.
3. Sanitize both the latest evidence file and the downstream context builder output.
4. Verify by scanning the exact files that feed the cron prompt.

Recommended character class:
- `\u200b\u200c\u200d\u2060\ufeff`

Practical note:
- Do not assume Markdown or terminal output is safe just because it looks normal.
- The issue often lives inside copied names or Slack snippets, not in the visible wrapper text.
