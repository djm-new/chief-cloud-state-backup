---
name: product-mockup-compositing
description: Use when placing a logo, wordmark, label, or graphic onto a product photo or mockup. Composite the asset cleanly, preserve realism, and verify the result visually.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [creative, image-editing, compositing, mockup, logo-placement]
    related_skills: [comfyui, sketch, claude-design]
---

# Product Mockup Compositing

## Overview

Use this skill when the user wants a logo, wordmark, badge, label, or simple graphic placed onto a photo of a physical object: tote bag, shirt, mug, box, package, sign, laptop, poster, or similar mockup.

The goal is not merely to paste pixels on top of the image. The composite should look like a believable print, embroidery, sticker, or screen print depending on the object and the source material. Prefer the simplest edit that preserves the original product photo and makes the requested branding legible.

A small support note with a proven ffmpeg workflow lives at `references/ffmpeg-overlay-notes.md`.

## When to Use

- User says things like:
  - "put this logo on the bag"
  - "add our mark to the shirt"
  - "mock this on a mug"
  - "overlay the label on the package"
  - "place the wordmark on the box photo"
- You have a product/photo background and a separate logo or graphic asset.
- The user wants a fast mockup, not a full brand redesign.
- The user wants the result to stay visually natural instead of looking like a screenshot overlay.

Do *not* use this for:
- Full multi-slide brand decks
- Pure vector logo design from scratch
- General generative image creation when no source photo is provided

## Workflow

### 1) Inspect the source images first

- Check image dimensions and aspect ratio.
- Determine whether the logo asset already has transparency.
- Identify the main printable area of the product.
- Look for perspective, folds, shadows, or seams that affect placement.

### 2) Prefer the cleanest compositing path

Use the least destructive method that fits the files you have:

- **Transparent logo asset:** overlay directly, scaling to fit the target surface.
- **Opaque logo on flat background:** remove the background first if it is uniform enough.
- **Photographic logo asset:** if the logo sits on a single flat-color card/background, try a color-key or alpha extraction pass before overlaying.
- **Complex logo cleanup:** if the source background is not cleanly removable, consider manual editing or a different asset instead of forcing a bad key.

### 3) Fit the logo to the product

- Scale based on the printable area, not the full image.
- Keep the logo centered unless the product layout suggests otherwise.
- Match the apparent orientation of the surface.
- If the product is angled, slightly adjust size and placement so it sits on the visible face.

### 4) Keep realism

- Avoid a giant flat rectangle around the logo.
- Avoid hard-edged boxes behind logos unless the user explicitly wants a sticker/panel look.
- If the logo should feel printed, use subtle opacity, shadow reduction, or blending rather than a bright opaque plaque.
- Do not over-process the image; the original texture should still read through when appropriate.

### 5) Verify visually

Before replying:

- Check that the logo is readable.
- Check that it is placed on the intended surface.
- Check that any background cleanup did not leave a visible rectangle.
- Check that the logo looks centered and proportionate.

If the first pass looks wrong, iterate once with a different scale, position, or cleanup method before handing it back.

## Practical Tooling Notes

- `ffmpeg` can be a fast way to scale and overlay assets.
- For simple text/wordmarks, `drawtext` can be enough.
- For image logos, `overlay` with `scale` is usually the quickest route.
- `colorkey` can help remove near-uniform light backgrounds from logo assets before compositing.
- Use `vision_analyze` on the final render when available to catch obvious placement or readability problems.

## Common Pitfalls

1. **Using a bad logo cleanup method and leaving a visible box.**
   If the source background is not uniform enough, stop and try another asset or a different cleanup threshold.

2. **Sizing the logo against the whole canvas instead of the printable area.**
   Place the brand relative to the object face, not the entire image frame.

3. **Making the logo too small to read.**
   If the user asked for a brand mark, readability usually matters more than subtlety.

4. **Creating a fake brand panel when the object should look printed.**
   Keep the composite natural unless the user requested a label or plaque.

5. **Skipping visual verification.**
   Always inspect the result after compositing; a technically successful overlay can still look awkward.

6. **Over-committing to one method.**
   If a keyed background still looks wrong, switch to a cleaner asset, different cleanup threshold, or manual placement instead of iterating endlessly.

## Verification Checklist

- [ ] Source logo/background was inspected before editing
- [ ] The logo is readable at final size
- [ ] Placement matches the product face and perspective
- [ ] No unwanted rectangle or matte remains around the logo
- [ ] The final image looks like a believable product mockup
- [ ] A visual check was performed on the exported result
